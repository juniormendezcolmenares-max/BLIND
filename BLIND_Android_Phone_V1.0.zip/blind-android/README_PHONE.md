# BLIND V1.0 — flujo 100% desde el celular

Este proyecto está preparado para que BLIND se pueda compilar sin Android Studio en una PC.

## Método recomendado: GitHub Actions

1. En el celular crea un repositorio nuevo en GitHub. Puede ser privado.
2. Sube el contenido de esta carpeta al repositorio, respetando la estructura:
   - `app/`
   - `build.gradle`
   - `settings.gradle`
   - `gradle.properties`
   - `.github/workflows/build-apk.yml`
3. En GitHub abre **Actions**.
4. Entra a **Build BLIND APK**.
5. Pulsa **Run workflow** si quieres lanzar una compilación manual.
6. Espera a que termine correctamente.
7. Abre la ejecución terminada y descarga el artefacto **BLIND-debug-apk**.
8. Descomprime el ZIP y toca `app-debug.apk` para instalar BLIND en tu teléfono.

También se recompila automáticamente cuando haces push a `main`.

## Para seguir desarrollando desde el teléfono

Puedes editar los archivos desde la web de GitHub o desde cualquier editor de código Android. Cada cambio que llegue a `main` puede generar un APK nuevo mediante Actions.

## Importante

- La V1.0 web original se mantiene como base dentro de `app/src/main/assets/index.html`.
- Este proyecto Android es una copia de trabajo; no modifica el archivo maestro de BLIND V1.0.
- El APK de debug sirve para pruebas. Para publicar en Google Play después necesitaremos una firma de lanzamiento y un AAB.
- No se necesita Android Studio en una PC para este flujo.
