# BLIND Android

Base: BLIND_V1.0.html. The master V1.0 remains unchanged in the Library; this is a separate Android working copy.

## Structure
- app/src/main/assets/index.html — current BLIND V1.0 web UI
- app/src/main/java/com/blind/app/MainActivity.java — Android WebView shell
- app/src/main/AndroidManifest.xml — app permissions/launcher
- app/src/main/res/values/styles.xml — dark BLIND shell theme

## Next steps
1. Open this folder in Android Studio.
2. Sync Gradle and run on an Android device/emulator.
3. Test WebView-specific behavior (keyboard, video, file picker, viewport).
4. Later replace local/mock data with APIs/backend and add native capabilities as needed.
